﻿using System;
using System.Runtime.Caching;


namespace OutSystems.CircuitBreakerLibrary
{
    public class CssCircuitBreakerDotNetMemoryCache : ICircuitBreakerMemoryCache
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ssKey"></param>
        /// <param name="ssValue"></param>
        public void Cache_Set(string ssKey, string ssValue)
        {

            //Store data in cache
            Cache.CacheProvider.Set(ssKey, ssValue as object);

        } // MssDotNetMemoryCache_Set

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ssKey"></param>
        /// <param name="ssValue"></param>
        public void Cache_Get(string ssKey, out string ssValue)
        {

            //Get data from cache
            ssValue = Cache.CacheProvider.Get(ssKey).ToString();

        } // MssDotNetMemoryCache_Get

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ssKey"></param>
        /// <param name="ssExists"></param>
        public void Cache_Exists(string ssKey, out bool ssExists)
        {

            //Get data from cache
            ssExists = Cache.CacheProvider.Exists(ssKey);

        } // MssDotNetMemoryCache_Exists 
    }

    static class Cache
    {
        private static RuntimeCacheProvider _cacheProvider = null;

        static Cache()
        {
            _cacheProvider = (new CacheProviderFactory()).Create(CacheProviderFactory.CacheProviderType.RuntimeCacheProvider);
        }

        public static RuntimeCacheProvider CacheProvider
        {
            get
            {
                return (_cacheProvider);
            }
        }
    }

    public class CacheProviderFactory
    {
        public enum CacheProviderType
        {
            RuntimeCacheProvider
        }

        public RuntimeCacheProvider Create(CacheProviderType pInType)
        {
            switch (pInType)
            {
                case CacheProviderType.RuntimeCacheProvider:
                    return new RuntimeCacheProvider();

                default:
                    throw new ArgumentException("Invalid cache provider type", "pInType");
            }
        }
    }

    public class RuntimeCacheProvider
    {
        //Not an engineer masterpiece, but it serves the purpose


        public object Get(string pInKey)
        {
            //Return key entry value
            return (MemoryCache.Default.Get(pInKey));
        }

        public void Set(string pInKey, object pInValue)
        {
            //Create cache policy. Objects do not expire
            CacheItemPolicy cacheItemPolicy = new CacheItemPolicy() { AbsoluteExpiration = MemoryCache.InfiniteAbsoluteExpiration };

            //Store value in cache
            MemoryCache.Default.Set(new CacheItem(pInKey, pInValue), cacheItemPolicy);
        }

        public bool Exists(string pInKey)
        {
            //Check if exists
            return (MemoryCache.Default.Contains(pInKey));
        }
    }
}
