﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutSystems.ExternalLibraries.SDK;

namespace OutSystems.CircuitBreakerLibrary
{
    [OSInterface(Description = "Circuit Breaker Memory Cache", IconResourceName = "OutSystems.CircuitBreakerLibrary.resources.microchip.png")]  
  
    public interface ICircuitBreakerMemoryCache
    {        
        void Cache_Set(string ssKey, string ssValue);
        void Cache_Get(string ssKey, out string ssValue);
        void Cache_Exists(string ssKey, out bool ssExists);    
    }
}
